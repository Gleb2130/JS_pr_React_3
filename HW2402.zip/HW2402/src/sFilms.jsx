import React, { useState ,useEffect} from 'react';
import './toDo.css';
import filmList from './filmList';
import {filmD,importLS,exportLS} from './filmdata';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import { nanoid } from "nanoid";

const ShowFilms = () => {
    importLS();
    exportLS();

    const [name, setName] = useState("");
    const [poster, setPoster] = useState("");
    const [age, setAge] = useState(0);
    const [description, setDescription] = useState("");
    const [filmData, setFilmData] = useState(filmD);
    const [favoriteCount, setFavoriteCount] = useState(0);
    const [sortFavFilms,setsortFavFilms] = useState(false)
    const AddFilm = () => {
        const film = {
            id: nanoid(),
            name: name,
            poster: poster,
            age: age,
            description: description,
            favorite:false,
        };

        setFilmData(prevData => [...prevData, film]);
        localStorage.setItem(localStorage.length,JSON.stringify(film))
    }
    const sortFav=()=>{
        sortFavFilms?setsortFavFilms(false):setsortFavFilms(true);
    }

    useEffect(() => {
        const countFavorites = filmData.filter(item => item.favorite).length;
        setFavoriteCount(countFavorites);
    }, [filmData]);

    return (
        <>
            <div>
                <span>Name:</span>
                <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)} />
                <br />
                <span>Poster:</span>
                <input
                    type="text"
                    value={poster}
                    onChange={(e) => setPoster(e.target.value)} />
                <br />
                <span>Age:</span>
                <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(e.target.value)} />
                <br />
                <span>Description:</span>
                <input
                    type="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)} />
                <br />
                <button onClick={AddFilm}>Add</button>
                <button onClick={sortFav}><FavoriteBorderIcon/> {favoriteCount}</button>
            </div>
            {filmData.map((obj) => filmList(obj, setFilmData,sortFavFilms))}
        </>
    );
}

export default ShowFilms;